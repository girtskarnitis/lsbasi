Direktorija satur 3 failus:
ReadMe.txt
Interpretators_V3.py
test1.cpl

Lai darbinātu interpretatoru, nepieciešama python versija 3.8.x 
Interpretatoru darbina comandrindā direktorijā, kur atrodas šie faili ievadot komandu:

python Interpretators_V3.py Test1.cpl

Rezultātā tiks izdoti visi iespējamie programmas izpildes ceļi, konkrētās izpildes rezultāti. kā arī šo ceļu iziešana nosacījumi.

